return {

    [tes3.objectType.probe] = true,
    [tes3.objectType.lockpick] = true,
    [tes3.objectType.apparatus] = true,
    [tes3.objectType.repairItem] = true,

}