return {

    armor = "Press this button to start editing Armors and Shields.",
    books = "Press this button to start editing Books and Scrolls.",
    clothing = "Press this button to start editing Clothing Items.",
    consumables = "Press this button to start editing Potions and Ingredients.",
    lights = "Press this button to start editing Light Items.",
    misc = "Press this button to start editing Miscelanious Items.",
    spells = "Press this button to start editing Spells.",
    tools = "Press this button to start editing Lockpicks, Probes, Alchemy Apparatuses and Repair Items.",
    weapons = "Press this button to start editing Weapons, Arrows and Bolts.",

    reset = "Press this button to restore an edited item to it's Default Condition.",

}