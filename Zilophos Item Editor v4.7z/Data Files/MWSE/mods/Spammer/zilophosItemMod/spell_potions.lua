return {

    [tes3.objectType.alchemy] = 4,
    [tes3.objectType.spell] = 8

}